package com.drjukka.heartbeatsimulator;

import android.bluetooth.BluetoothManager;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity implements HeartBeatAdvertiserCallback {

    private final String TAG = "HEARTBEAT_SIM";
    private final MainActivity self = this;

    private HeartBeatModel mHeartBeatModel = null;

    private int mInterval = 1000; // 1 second by default, can be changed later
    private Handler timeHandler;
    private int valueHB = 50;
    private boolean directionUp = true;

    Runnable mStatusChecker = new Runnable() {
        @Override
        public void run() {

            if(directionUp){
                valueHB++;
            }else{
                valueHB--;
            }

            if(valueHB < 50){
                directionUp = true;
            }

            if(valueHB > 100){
                directionUp = false;
            }

            if(self.mHeartBeatModel != null){
                self.mHeartBeatModel.setHeartbeatValue(valueHB);
                Log.i(TAG, "Set value : " + valueHB);

            }

            timeHandler.postDelayed(mStatusChecker, mInterval);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final Button button = (Button) findViewById(R.id.StartNode);
        button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                if (self.mHeartBeatModel == null || !self.mHeartBeatModel.isStarted()) {
                    Start();
                } else {
                    Stop();
                }
            }
        });

        timeHandler = new Handler();
        mStatusChecker.run();
    }

    public void Start() {
        Log.i(TAG, "Start-");

        String manData = "052B006B";
        if(mHeartBeatModel == null) {
            mHeartBeatModel = new HeartBeatModel(this,this);
            mHeartBeatModel.setbodySensorLocation(5);
            mHeartBeatModel.setBatteryLevel(50);
        }
        mHeartBeatModel.start();
    }

    public void Stop() {
        Log.i(TAG, "Stop-");

        HeartBeatModel tmpModel = mHeartBeatModel;
        mHeartBeatModel = null;
        if(tmpModel != null)
        {
            tmpModel.stop();
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onAdvertisingStarted(String error) {
        Log.i(TAG, "onAdvertisingStarted : " + error);
    }

    @Override
    public void onAdvertisingStopped(String error) {
        Log.i(TAG, "onAdvertisingStarted : " + error);
    }
}
