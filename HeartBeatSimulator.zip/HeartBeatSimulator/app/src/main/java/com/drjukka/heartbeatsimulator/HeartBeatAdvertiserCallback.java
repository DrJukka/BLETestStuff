package com.drjukka.heartbeatsimulator;

/**
 * Created by juksilve on 27.8.2015.
 */
interface HeartBeatAdvertiserCallback {
    void onAdvertisingStarted(String error);
    void onAdvertisingStopped(String error);
}
